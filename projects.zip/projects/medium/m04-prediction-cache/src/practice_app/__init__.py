"""Local prediction cache application."""
