"""Local evaluation runner application."""
