"""Local contributor assignment application."""
