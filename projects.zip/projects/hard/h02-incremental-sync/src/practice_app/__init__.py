"""Local incremental sync application."""
