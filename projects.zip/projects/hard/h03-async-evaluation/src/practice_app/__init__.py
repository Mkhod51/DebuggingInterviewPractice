"""Local asynchronous evaluation application."""
