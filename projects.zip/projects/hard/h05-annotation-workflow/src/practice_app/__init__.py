"""Local annotation workflow application."""
