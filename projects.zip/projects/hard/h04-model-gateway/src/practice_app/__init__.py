"""Local model gateway application."""
