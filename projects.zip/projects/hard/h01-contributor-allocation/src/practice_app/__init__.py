"""Local contributor allocation application."""
