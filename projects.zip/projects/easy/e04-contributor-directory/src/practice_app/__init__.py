"""Local contributor directory application."""
