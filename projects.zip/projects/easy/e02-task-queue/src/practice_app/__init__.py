"""Local task queue application."""
