"""Local quality scores application."""
