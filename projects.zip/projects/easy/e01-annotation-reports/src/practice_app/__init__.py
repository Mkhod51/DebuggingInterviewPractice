"""Local annotation reports application."""
